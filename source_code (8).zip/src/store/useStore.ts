import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { Member, Loan, Contribution, EMIRecord, AppSettings, Notification, PenaltyRecord, ManualInterestRecord, PendingInterest, SavingsTransaction, NotificationTemplate } from '../types';
import { generateId, getDefaultPassword, calculateLoanDetails, getMonthKey, getContributionDueDate, calculatePenaltyDays } from '../utils/calculations';

const DEFAULT_MEMBERS: Omit<Member, 'id'>[] = [
  { name: 'ADMIN', mobile: '9315341037', password: '1311', joiningDate: '2025-09-10', isAdmin: true, isActive: true, language: 'hi', jamaBalance: 0, autoDeductPenalty: false },
  { name: 'NISHA', mobile: '9711321568', password: '1568', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'MEENA', mobile: '9289137685', password: '7685', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'REKHA', mobile: '7678253940', password: '3940', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'AMISHA', mobile: '9211984237', password: '4237', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'MADHU', mobile: '7838140223', password: '0223', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'RACHNA', mobile: '8445669184', password: '9184', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'LATESH', mobile: '7017162405', password: '2405', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'SEEMA', mobile: '7525820593', password: '0593', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'SEETA', mobile: '8303972736', password: '2736', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'MUSKAN', mobile: '9935593567', password: '3567', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'AVNISH', mobile: '9654784185', password: '4185', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'ASHOK', mobile: '9354276567', password: '6567', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'RAVI ARUMUGAM', mobile: '9711891954', password: '1954', joiningDate: '2025-09-10', isAdmin: false, isActive: true, language: 'en', jamaBalance: 0, autoDeductPenalty: true },
  { name: 'RAMNIWAS', mobile: '9205231995', password: '1995', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'LUCKY', mobile: '9911303276', password: '3276', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'MAHESH', mobile: '8700569722', password: '9722', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'MONI', mobile: '9958422693', password: '2693', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'CHAMAN', mobile: '9911352254', password: '2254', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'INDERJEET', mobile: '8285072541', password: '2541', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
  { name: 'N.P. SINGH', mobile: '9315341038', password: '1038', joiningDate: '2025-09-10', isAdmin: false, isActive: true, jamaBalance: 0, autoDeductPenalty: true },
];

const DEFAULT_SETTINGS: AppSettings = {
  upiId: '9315341037@ybl',
  groupName: 'SHG BANK',
  monthlyContribution: 1000,
  maxLoanAmount: 15000,
  interestRate: 2,
  lateFeePerDay: 10,
  dueDate: 11,
};

// Members to be removed (case-insensitive)
const MEMBERS_TO_REMOVE = ['karan', 'raju', 'poonam'];

// Helper to remove member and all related data
const removeMemberAndData = (state: AppState): Partial<AppState> => {
  const membersToRemove = state.members
    .filter(m => MEMBERS_TO_REMOVE.includes(m.name.toLowerCase()))
    .map(m => m.id);
  
  if (membersToRemove.length === 0) return {};
  
  return {
    members: state.members.filter(m => !membersToRemove.includes(m.id)),
    loans: state.loans.filter(l => !membersToRemove.includes(l.memberId)),
    contributions: state.contributions.filter(c => !membersToRemove.includes(c.memberId)),
    penalties: state.penalties.filter(p => !membersToRemove.includes(p.memberId)),
    manualInterests: state.manualInterests.filter(mi => !membersToRemove.includes(mi.memberId)),
  };
};

interface AppState {
  // Auth
  currentUserId: string | null;
  
  // Data
  members: Member[];
  loans: Loan[];
  contributions: Contribution[];
  penalties: PenaltyRecord[];
  manualInterests: ManualInterestRecord[];
  pendingInterests: PendingInterest[];
  notifications: Notification[];
  settings: AppSettings;
  language: 'hi' | 'en' | 'ta';
  lastInterestDistribution: string | null;
  
  // Savings
  savingsTransactions: SavingsTransaction[];
  savingsInterestRate: number;
  notificationTemplates: NotificationTemplate[];
  
  // Auth actions
  login: (mobile: string, password: string) => Member | null;
  logout: () => void;
  changePassword: (memberId: string, newPassword: string) => void;
  resetMemberPassword: (memberId: string) => void;
  
  // Member actions
  addMember: (name: string, mobile: string, joiningDate: string) => void;
  recoverMember: (name: string, mobile: string, joiningDate: string, password?: string) => void;
  removeMember: (memberId: string) => void;
  
  // Settlement/Quit
  settleMemberAccount: (memberId: string) => {
    totalContribution: number;
    totalEarnings: number;
    totalLoans: number;
    remainingBalance: number;
    settlementAmount: number;
  } | null;
  updateMember: (memberId: string, data: Partial<Member>) => void;
  setProfilePhoto: (memberId: string, photo: string) => void;
  
  // Loan actions
  applyForLoan: (memberId: string, amount: number, months: number, interestRate?: number) => void;
  recallLoan: (loanId: string) => void;
  approveLoan: (loanId: string) => void;
  rejectLoan: (loanId: string) => void;
  forecloseLoan: (loanId: string) => void;
  addOldLoan: (data: { memberId: string; amount: number; openingDate: string; closingDate?: string; includeInterest: boolean; months: number; interestRate?: number; shareWithMembers?: boolean }) => void;
  
  // EMI actions
  addEMIPayment: (loanId: string, emiNumber: number, paidDate: string, applyPenalty: boolean, flexibleAmount?: number) => void;
  
  // Contribution actions
  addContribution: (memberId: string, month: string, paidDate: string, applyPenalty: boolean) => void;
  addBulkContribution: (month: string, memberIds: string[], paidDate: string, applyPenalty: boolean) => void;
  
  // Manual interest
  addManualInterest: (memberId: string, amount: number, date: string, description: string) => void;
  removeManualInterest: (id: string) => void;
  clearAllManualInterests: () => void;
  getMemberManualInterest: (memberId: string) => number;
  
  // Admin edit
  editContribution: (contributionId: string, data: Partial<Contribution>) => void;
  editEMI: (loanId: string, emiId: string, data: Partial<EMIRecord>) => void;

  // Admin delete
  deleteContribution: (contributionId: string) => void;
  deleteEMIPayment: (loanId: string, emiId: string) => void;
  deleteLoan: (loanId: string) => void;
  toggleLoanInApp: (loanId: string) => void;
  
  // Settings
  updateSettings: (data: Partial<AppSettings>) => void;
  setLanguage: (lang: 'hi' | 'en' | 'ta') => void;
  
  // Notifications
  addNotification: (message: string, type: 'broadcast' | 'loan_holder', targetMemberId?: string, sentVia?: 'sms' | 'whatsapp' | 'both') => void;
  
  // Savings
  addSavingsDeposit: (memberId: string, amount: number, date: string, description: string) => void;
  addSavingsWithdrawal: (memberId: string, amount: number, date: string, description: string) => void;
  getMemberSavingsBalance: (memberId: string) => number;
  getMemberSavingsTransactions: (memberId: string) => SavingsTransaction[];
  getTotalSavings: () => number;
  
  // Jama (Collection) Management
  addJamaDeposit: (memberId: string, amount: number, date: string, description: string) => void;
  addJamaWithdrawal: (memberId: string, amount: number, date: string, description: string) => void;
  getMemberJamaBalance: (memberId: string) => number;
  applyAutoPenaltyFromJama: (memberId: string, contributionId: string) => { success: boolean; message: string };
  getTotalJama: () => number;
  
  // Notification Templates
  addNotificationTemplate: (template: Omit<NotificationTemplate, 'id'>) => void;
  deleteNotificationTemplate: (templateId: string) => void;
  
  // CSV Export
  exportMemberCSV: (memberId: string) => string;
  exportMonthlyCSV: (month: string) => string;
  
  // Seed historical contributions
  seedHistoricalContributions: () => void;

  // Computed getters
  getMember: (id: string) => Member | undefined;
  getMemberByMobile: (mobile: string) => Member | undefined;
  getMemberLoans: (memberId: string) => Loan[];
  getMemberContributions: (memberId: string) => Contribution[];
  getMemberTotalContribution: (memberId: string) => number;
  getMemberPenaltyShare: (memberId: string) => number;
  getMemberInterestShare: (memberId: string) => number;
  getMemberTotalEarnings: (memberId: string) => number;
  getMemberGrandTotal: (memberId: string) => number;
  getActiveLoans: () => Loan[];
  getPendingLoans: () => Loan[];
  getTotalCollection: () => number;
  getTotalLoansGiven: () => number;
  getRemainingBalance: () => number;
  getTotalPenaltyCollected: () => number;
  getTotalInterestCollected: () => number;
  getDefaulterNames: () => string[];
  canApplyLoan: (memberId: string) => boolean;
  toggleMemberActive: (memberId: string, inactiveDate?: string) => void;
  
  // Period interest calculation
  calculateInterestForPeriod: (startDate: string, endDate: string) => number;
  getPeriodInterestShare: (memberId: string, startDate: string, endDate: string) => number;
  distributePeriodInterest: (startDate: string, endDate: string, description: string) => void;
  
  // Pending interest (automatic from loans)
  getMemberPendingInterest: (memberId: string) => number;
  distributePendingInterests: () => void;
  autoDistributePendingInterest: () => void;
  
  // Reset all data to default
  resetData: () => void;
}

export const useStore = create<AppState>()(
  persist(
    (set, get) => ({
      currentUserId: null,
      members: DEFAULT_MEMBERS.map((m, i) => ({ ...m, id: `member_${i}_${m.mobile}` })),
      loans: [],
      contributions: [
        { id: 'contrib_gopal_2026-05', memberId: 'member_23_7678457729', memberName: 'GOPAL SHARMA (Tea)', amount: 1000, month: '2026-05', dueDate: '2026-05-11', paidDate: '2026-05-12', penalty: 0, status: 'paid', approvedByMember: true },
      ],
      pendingInterests: [],
      lastInterestDistribution: null,
      savingsTransactions: [],
      savingsInterestRate: 6,
      notificationTemplates: [
        { id: '1', name: 'Contribution Reminder', message: 'नमस्ते {name}, याद रहे कि इस महीने का ₹{amount} का योगदान जमा करना है। देय तिथि: {dueDate}', type: 'reminder' },
        { id: '2', name: 'EMI Due Reminder', message: 'नमस्ते {name}, आपका EMI ₹{amount} देय है। कृपया समय पर भुगतान करें।', type: 'emi' },
        { id: '3', name: 'Loan Approved', message: 'बधाई हो {name}! आपका ₹{amount} का ऋण स्वीकृत हो गया है।', type: 'loan' },
        { id: '4', name: 'Festival Greeting', message: 'आपको {festival} की हार्दिक शुभकामनाएं! {groupName} परिवार की ओर से।', type: 'festival' },
      ],

      login: (mobile, password) => {
        const member = get().members.find(m => m.mobile === mobile && m.password === password);
        if (member) {
          set({ currentUserId: member.id });
          
          // Auto-distribute pending interests when admin logs in
          if (member.isAdmin) {
            get().autoDistributePendingInterest();
          }
          
          return member;
        }
        return null;
      },

      logout: () => set({ currentUserId: null }),

      changePassword: (memberId, newPassword) => {
        set(s => ({
          members: s.members.map(m => m.id === memberId ? { ...m, password: newPassword } : m),
        }));
      },

      resetMemberPassword: (memberId) => {
        const member = get().members.find(m => m.id === memberId);
        if (member) {
          get().changePassword(memberId, getDefaultPassword(member.mobile));
        }
      },

      addMember: (name, mobile, joiningDate) => {
        const newMember: Member = {
          id: generateId(),
          name,
          mobile,
          password: getDefaultPassword(mobile),
          joiningDate,
          isAdmin: false,
          isActive: true,
        };
        set(s => ({ members: [...s.members, newMember] }));
      },

      recoverMember: (name, mobile, joiningDate, password) => {
        // Check if member already exists - if so, just make them active
        const exists = get().members.find(m => m.mobile === mobile);
        if (exists) {
          // Just make them active again
          set(s => ({
            members: s.members.map(m => m.mobile === mobile ? { ...m, isActive: true } : m)
          }));
          alert(`${name} को सक्रिय कर दिया गया!`);
          return;
        }
        // Add new member
        const newMember: Member = {
          id: generateId(),
          name,
          mobile,
          password: password || getDefaultPassword(mobile),
          joiningDate,
          isAdmin: false,
          isActive: true,
        };
        set(s => ({ members: [...s.members, newMember] }));
        alert(`${name} को सफलतापूर्वक पुनर्स्थापित किया गया!`);
      },

      removeMember: (memberId) => {
        set(s => ({
          // Remove the member completely
          members: s.members.filter(m => m.id !== memberId),
          // Remove all loans for this member
          loans: s.loans.filter(l => l.memberId !== memberId),
          // Remove all contributions for this member
          contributions: s.contributions.filter(c => c.memberId !== memberId),
          // Remove all penalties for this member
          penalties: s.penalties.filter(p => p.memberId !== memberId),
          // Remove all manual interests for this member
          manualInterests: s.manualInterests.filter(mi => mi.memberId !== memberId),
        }));
      },

      settleMemberAccount: (memberId) => {
        const member = get().getMember(memberId);
        if (!member) return null;
        
        const totalContribution = get().getMemberTotalContribution(memberId);
        const totalEarnings = get().getMemberTotalEarnings(memberId);
        const loans = get().getMemberLoans(memberId);
        const activeLoans = loans.filter(l => l.status === 'active');
        const totalLoans = activeLoans.reduce((acc, l) => acc + l.remainingAmount, 0);
        const savingsBalance = get().getMemberSavingsBalance(memberId);
        
        // Settlement = Total Contribution + Earnings + Savings - Outstanding Loans
        const settlementAmount = totalContribution + totalEarnings + savingsBalance - totalLoans;
        
        // Remove all member data
        set(s => ({
          members: s.members.filter(m => m.id !== memberId),
          loans: s.loans.filter(l => l.memberId !== memberId),
          contributions: s.contributions.filter(c => c.memberId !== memberId),
          penalties: s.penalties.filter(p => p.memberId !== memberId),
          manualInterests: s.manualInterests.filter(mi => mi.memberId !== memberId),
          savingsTransactions: s.savingsTransactions.filter(t => t.memberId !== memberId),
        }));
        
        return {
          totalContribution,
          totalEarnings,
          totalLoans,
          remainingBalance: savingsBalance,
          settlementAmount,
        };
      },

      updateMember: (memberId, data) => {
        set(s => ({
          members: s.members.map(m => m.id === memberId ? { ...m, ...data } : m),
        }));
      },

      setProfilePhoto: (memberId, photo) => {
        set(s => ({
          members: s.members.map(m => m.id === memberId ? { ...m, profilePhoto: photo } : m),
        }));
      },

      applyForLoan: (memberId, amount, months, interestRate = 2) => {
        const member = get().members.find(m => m.id === memberId);
        if (!member) return;
        const rate = interestRate / 100;
        const details = calculateLoanDetails(amount, months, rate);
        const now = new Date();
        const closingDate = new Date(now.getFullYear(), now.getMonth() + months, now.getDate());
        const loan: Loan = {
          id: generateId(),
          memberId,
          memberName: member.name,
          amount,
          interestRate,
          months,
          totalInterest: details.totalInterest,
          totalPayable: details.totalPayable,
          emiAmount: details.emi,
          remainingAmount: details.totalPayable,
          openingDate: now.toISOString(),
          closingDate: closingDate.toISOString(),
          nextEmiDate: new Date(now.getFullYear(), now.getMonth() + 1, 11).toISOString(),
          status: 'pending',
          includeInterest: true,
          isOldLoan: false,
          includeInApp: true, // Default: track this loan
          emiHistory: details.breakdown.map((b, i) => ({
            id: generateId(),
            loanId: '',
            memberId,
            emiNumber: i + 1,
            amount: b.amount,
            interestComponent: b.interest,
            principalComponent: b.principal,
            dueDate: new Date(now.getFullYear(), now.getMonth() + i, 11).toISOString(),
            penalty: 0,
            status: 'pending' as const,
            approvedByMember: false,
          })),
        };
        loan.emiHistory = loan.emiHistory.map(e => ({ ...e, loanId: loan.id }));
        set(s => ({ loans: [...s.loans, loan] }));
      },

      recallLoan: (loanId) => {
        set(s => ({
          loans: s.loans.map(l => l.id === loanId ? { ...l, status: 'recalled' as const } : l),
        }));
      },

      approveLoan: (loanId) => {
        const loan = get().loans.find(l => l.id === loanId);
        if (!loan) return;
        
        // Calculate the next 10th date for pending interest distribution
        const now = new Date();
        const nextMonth = new Date(now.getFullYear(), now.getMonth() + 1, 10);
        const targetDate = nextMonth.toISOString().split('T')[0];
        
        // Calculate monthly interest from EMI (first EMI's interest component)
        const monthlyInterest = loan.emiHistory.length > 0 ? loan.emiHistory[0].interestComponent : 0;
        
        // Add pending interest for automatic distribution on 10th
        if (monthlyInterest > 0) {
          const pendingInterest: PendingInterest = {
            id: generateId(),
            memberId: loan.memberId,
            loanId: loan.id,
            amount: Math.round(monthlyInterest * 100) / 100,
            createdDate: now.toISOString().split('T')[0],
            targetDate,
            description: `Loan ${loan.amount} पर ब्याज (${loan.months} महीने)`,
          };
          set(s => ({ pendingInterests: [...s.pendingInterests, pendingInterest] }));
        }
        
        set(s => ({
          loans: s.loans.map(l => l.id === loanId ? { ...l, status: 'active' as const } : l),
        }));
      },

      rejectLoan: (loanId) => {
        set(s => ({
          loans: s.loans.map(l => l.id === loanId ? { ...l, status: 'rejected' as const } : l),
        }));
      },

      forecloseLoan: (loanId) => {
        const today = new Date().toISOString().split('T')[0];
        set(s => ({
          loans: s.loans.map(l => l.id === loanId ? {
            ...l,
            status: 'completed' as const,
            closingDate: today,
            remainingAmount: 0,
            emiHistory: l.emiHistory.map(e => e.status === 'pending' ? { ...e, status: 'paid' as const } : e),
          } : l),
        }));
      },

      addOldLoan: ({ memberId, amount, openingDate, closingDate = '', includeInterest, months, interestRate = 2, shareWithMembers = true }) => {
        const member = get().members.find(m => m.id === memberId);
        if (!member) return;
        const rate = includeInterest ? (interestRate / 100) : 0;
        const details = calculateLoanDetails(amount, months, rate);
        const isClosed = !!closingDate;
        const loan: Loan = {
          id: generateId(),
          memberId,
          memberName: member.name,
          amount,
          interestRate: includeInterest ? interestRate : 0,
          months,
          totalInterest: includeInterest ? details.totalInterest : 0,
          totalPayable: details.totalPayable,
          emiAmount: details.emi,
          remainingAmount: isClosed ? 0 : details.totalPayable,
          openingDate,
          closingDate: closingDate || '',
          nextEmiDate: new Date(new Date(openingDate).getFullYear(), new Date(openingDate).getMonth() + 1, 11).toISOString(),
          status: isClosed ? 'completed' : 'active',
          includeInterest,
          isOldLoan: true,
          includeInApp: shareWithMembers, // Control whether interest is shared with members
          emiHistory: details.breakdown.map((b, i) => {
            const emiDate = new Date(new Date(openingDate).getFullYear(), new Date(openingDate).getMonth() + i, 11);
            return {
              id: generateId(),
              loanId: '',
              memberId,
              emiNumber: i + 1,
              amount: b.amount,
              interestComponent: b.interest,
              principalComponent: b.principal,
              dueDate: emiDate.toISOString(),
              penalty: 0,
              status: 'pending' as const,
              approvedByMember: false,
            };
          }),
        };
        loan.emiHistory = loan.emiHistory.map(e => ({ ...e, loanId: loan.id }));
        set(s => ({ loans: [...s.loans, loan] }));
      },

      addEMIPayment: (loanId, emiNumber, paidDate, applyPenalty, flexibleAmount = 0) => {
        set(s => {
          const loan = s.loans.find(l => l.id === loanId);
          if (!loan) return s;
          const emi = loan.emiHistory.find(e => e.emiNumber === emiNumber);
          if (!emi || emi.status === 'paid') return s;
          
          // Calculate total payment (EMI + flexible amount)
          const totalPayment = emi.amount + flexibleAmount;
          
          let penalty = 0;
          if (applyPenalty) {
            const daysLate = calculatePenaltyDays(emi.dueDate);
            if (daysLate > 0) {
              penalty = daysLate * s.settings.lateFeePerDay;
            }
          }

          const penaltyRecord: PenaltyRecord = penalty > 0 ? {
            id: generateId(),
            memberId: loan.memberId,
            type: 'emi',
            referenceId: emi.id,
            amount: penalty,
            date: paidDate,
            daysLate: Math.ceil(penalty / s.settings.lateFeePerDay),
          } : null as any;

          return {
            loans: s.loans.map(l => {
              if (l.id !== loanId) return l;
              return {
                ...l,
                remainingAmount: Math.max(0, l.remainingAmount - totalPayment),
                emiHistory: l.emiHistory.map(e =>
                  e.emiNumber === emiNumber
                    ? { ...e, status: 'paid' as const, paidDate, penalty, amount: totalPayment, approvedByMember: true }
                    : e
                ),
                status: l.emiHistory.every(e => e.emiNumber === emiNumber ? true : e.status === 'paid') && l.emiHistory.filter(e => e.emiNumber === emiNumber || e.status === 'paid').length === l.months
                  ? 'completed' as const
                  : l.status,
              };
            }),
            penalties: penaltyRecord ? [...s.penalties, penaltyRecord] : s.penalties,
          };
        });
      },

      editEMI: (loanId, emiId, data) => {
        set(s => {
          const loan = s.loans.find(l => l.id === loanId);
          if (!loan) return s;
          const emi = loan.emiHistory.find(e => e.id === emiId);
          if (!emi) return s;
          
          const oldAmount = emi.amount;
          const oldPenalty = emi.penalty;
          const newAmount = data.amount ?? oldAmount;
          
          // Calculate the difference in amount to adjust remainingAmount
          const amountDiff = newAmount - oldAmount;
          
          return {
            loans: s.loans.map(l => {
              if (l.id !== loanId) return l;
              return {
                ...l,
                remainingAmount: Math.max(0, l.remainingAmount - amountDiff),
                emiHistory: l.emiHistory.map(e =>
                  e.id === emiId
                    ? { ...e, ...data }
                    : e
                ),
              };
            }),
            penalties: data.penalty !== undefined && data.penalty !== oldPenalty
              ? s.penalties.map(p => 
                  p.referenceId === emiId && p.type === 'emi'
                    ? { ...p, amount: data.penalty || 0 }
                    : p
                )
              : s.penalties,
          };
        });
      },

      addContribution: (memberId, month, paidDate, applyPenalty) => {
        const member = get().members.find(m => m.id === memberId);
        if (!member) return;
        const dueDate = getContributionDueDate(month);
        const existing = get().contributions.find(c => c.memberId === memberId && c.month === month);
        if (existing) return;

        let penalty = 0;
        if (applyPenalty) {
          const daysLate = calculatePenaltyDays(dueDate);
          if (daysLate > 0) penalty = daysLate * get().settings.lateFeePerDay;
        }

        const penaltyRecord: PenaltyRecord = penalty > 0 ? {
          id: generateId(),
          memberId,
          type: 'contribution',
          referenceId: '',
          amount: penalty,
          date: paidDate,
          daysLate: Math.ceil(penalty / get().settings.lateFeePerDay),
        } : null as any;

        const contribution: Contribution = {
          id: generateId(),
          memberId,
          memberName: member.name,
          amount: get().settings.monthlyContribution,
          month,
          dueDate,
          paidDate,
          penalty,
          status: 'paid',
          approvedByMember: true,
        };

        set(s => ({
          contributions: [...s.contributions, contribution],
          penalties: penaltyRecord ? [...s.penalties, penaltyRecord] : s.penalties,
        }));
      },

      addBulkContribution: (month, memberIds, paidDate, applyPenalty) => {
        memberIds.forEach(memberId => {
          get().addContribution(memberId, month, paidDate, applyPenalty);
        });
      },

      addManualInterest: (memberId, amount, date, description) => {
        const member = get().members.find(m => m.id === memberId);
        if (!member || amount <= 0) return;
        const record: ManualInterestRecord = {
          id: generateId(),
          memberId,
          memberName: member.name,
          amount,
          date,
          description,
        };
        set(s => ({ manualInterests: [...s.manualInterests, record] }));
      },

      removeManualInterest: (id) => {
        set(s => ({ manualInterests: s.manualInterests.filter(m => m.id !== id) }));
      },

      // Clear all manual interests (admin only)
      clearAllManualInterests: () => {
        set(s => ({ manualInterests: [] }));
      },

      getMemberManualInterest: (memberId) => {
        return get().manualInterests
          .filter(m => m.memberId === memberId)
          .reduce((sum, m) => sum + m.amount, 0);
      },

      editContribution: (contributionId, data) => {
        set(s => ({
          contributions: s.contributions.map(c => c.id === contributionId ? { ...c, ...data } : c),
        }));
      },

      deleteContribution: (contributionId) => {
        set(s => ({
          contributions: s.contributions.filter(c => c.id !== contributionId),
          penalties: s.penalties.filter(p => {
            const contrib = s.contributions.find(c => c.id === contributionId);
            return contrib ? p.referenceId !== contributionId : true;
          }),
        }));
      },

      deleteEMIPayment: (loanId, emiId) => {
        set(s => {
          const loan = s.loans.find(l => l.id === loanId);
          if (!loan) return s;
          const emi = loan.emiHistory.find(e => e.id === emiId);
          if (!emi) return s;

          const wasPaid = emi.status === 'paid';
          const penaltyRefunded = emi.penalty || 0;

          return {
            loans: s.loans.map(l => {
              if (l.id !== loanId) return l;
              const statusChanged = wasPaid ? 'active' as const : l.status;
              return {
                ...l,
                status: statusChanged,
                remainingAmount: Math.min(l.remainingAmount + (wasPaid ? emi.amount : 0), l.totalPayable),
                emiHistory: l.emiHistory.map(e =>
                  e.id === emiId
                    ? { ...e, status: 'pending' as const, paidDate: undefined, penalty: 0, approvedByMember: false }
                    : e
                ),
              };
            }),
            penalties: penaltyRefunded > 0
              ? s.penalties.filter(p => p.referenceId !== emiId)
              : s.penalties,
          };
        });
      },

      deleteLoan: (loanId) => {
        set(s => ({
          loans: s.loans.filter(l => l.id !== loanId),
        }));
      },

      toggleLoanInApp: (loanId) => {
        set(s => ({
          loans: s.loans.map(l => l.id === loanId ? { ...l, includeInApp: !l.includeInApp } : l),
        }));
      },

      updateSettings: (data) => {
        set(s => ({ settings: { ...s.settings, ...data } }));
      },

      setLanguage: (lang) => set({ language: lang }),

      addNotification: (message, type, targetMemberId, sentVia) => {
        const notification: Notification = {
          id: generateId(),
          message,
          date: new Date().toISOString(),
          type,
          targetMemberId,
          sentVia,
        };
        set(s => ({ notifications: [...s.notifications, notification] }));
      },

      // Savings implementations
      addSavingsDeposit: (memberId, amount, date, description) => {
        const member = get().getMember(memberId);
        if (!member) return;
        const transaction: SavingsTransaction = {
          id: generateId(),
          memberId,
          memberName: member.name,
          type: 'deposit',
          amount,
          date,
          description,
        };
        set(s => ({ savingsTransactions: [...s.savingsTransactions, transaction] }));
      },

      addSavingsWithdrawal: (memberId, amount, date, description) => {
        const member = get().getMember(memberId);
        if (!member) return;
        const balance = get().getMemberSavingsBalance(memberId);
        if (amount > balance) {
          alert('अपर्याप्त शेष राशि');
          return;
        }
        const transaction: SavingsTransaction = {
          id: generateId(),
          memberId,
          memberName: member.name,
          type: 'withdrawal',
          amount,
          date,
          description,
        };
        set(s => ({ savingsTransactions: [...s.savingsTransactions, transaction] }));
      },

      getMemberSavingsBalance: (memberId) => {
        const transactions = get().savingsTransactions.filter(t => t.memberId === memberId);
        return transactions.reduce((acc, t) => 
          t.type === 'deposit' ? acc + t.amount : acc - t.amount, 0
        );
      },

      getMemberSavingsTransactions: (memberId) => {
        return get().savingsTransactions.filter(t => t.memberId === memberId);
      },

      getTotalSavings: () => {
        return get().savingsTransactions.reduce((acc, t) => 
          t.type === 'deposit' ? acc + t.amount : acc - t.amount, 0
        );
      },

      // Jama (Collection) Management implementations
      addJamaDeposit: (memberId, amount, date, description) => {
        const member = get().getMember(memberId);
        if (!member) return;
        set(s => ({
          members: s.members.map(m => 
            m.id === memberId 
              ? { ...m, jamaBalance: m.jamaBalance + amount }
              : m
          ),
        }));
      },

      addJamaWithdrawal: (memberId, amount, date, description) => {
        const member = get().getMember(memberId);
        if (!member) return;
        if (member.jamaBalance < amount) return;
        set(s => ({
          members: s.members.map(m => 
            m.id === memberId 
              ? { ...m, jamaBalance: m.jamaBalance - amount }
              : m
          ),
        }));
      },

      getMemberJamaBalance: (memberId) => {
        const member = get().getMember(memberId);
        return member?.jamaBalance || 0;
      },

      applyAutoPenaltyFromJama: (memberId, contributionId) => {
        const member = get().getMember(memberId);
        const contribution = get().contributions.find(c => c.id === contributionId);
        
        if (!member || !contribution) {
          return { success: false, message: 'Member or contribution not found' };
        }

        if (!member.autoDeductPenalty) {
          return { success: false, message: 'Auto-deduct penalty is not enabled for this member' };
        }

        // Calculate penalty
        const daysLate = calculatePenaltyDays(contribution.dueDate);
        if (daysLate <= 0) {
          return { success: false, message: 'No penalty applicable - contribution is not yet overdue' };
        }

        const penaltyAmount = daysLate * get().settings.lateFeePerDay;

        if (member.jamaBalance < penaltyAmount) {
          return { success: false, message: `Insufficient jama balance. Required: ₹${penaltyAmount}, Available: ₹${member.jamaBalance}` };
        }

        // Deduct penalty from jama
        set(s => ({
          members: s.members.map(m => 
            m.id === memberId 
              ? { ...m, jamaBalance: m.jamaBalance - penaltyAmount }
              : m
          ),
          contributions: s.contributions.map(c => 
            c.id === contributionId 
              ? { ...c, penalty: penaltyAmount, status: 'paid', paidDate: new Date().toISOString().split('T')[0] }
              : c
          ),
          penalties: [...s.penalties, {
            id: generateId(),
            memberId,
            type: 'contribution',
            referenceId: contributionId,
            amount: penaltyAmount,
            date: new Date().toISOString().split('T')[0],
            daysLate,
          }],
        }));

        // Send WhatsApp notification
        const message = `नमस्ते ${member.name}, आपके जमा से ₹${penaltyAmount} का लेट पेनल्टी काटा गया है (${daysLate} दिन देरी के लिए)। शेष जमा: ₹${member.jamaBalance - penaltyAmount}`;
        get().addNotification(message, 'loan_holder', memberId, 'whatsapp');

        return { success: true, message: `₹${penaltyAmount} penalty deducted from jama and WhatsApp message sent` };
      },

      getTotalJama: () => {
        return get().members.reduce((acc, m) => acc + m.jamaBalance, 0);
      },

      addNotificationTemplate: (template) => {
        const newTemplate: NotificationTemplate = {
          ...template,
          id: generateId(),
        };
        set(s => ({ notificationTemplates: [...s.notificationTemplates, newTemplate] }));
      },

      deleteNotificationTemplate: (templateId) => {
        set(s => ({ 
          notificationTemplates: s.notificationTemplates.filter(t => t.id !== templateId) 
        }));
      },

      exportMemberCSV: (memberId) => {
        const member = get().getMember(memberId);
        const loans = get().getMemberLoans(memberId);
        const contributions = get().getMemberContributions(memberId);
        const totalContrib = get().getMemberTotalContribution(memberId);
        const penaltyShare = get().getMemberPenaltyShare(memberId);
        const interestShare = get().getMemberInterestShare(memberId);
        const grandTotal = totalContrib + penaltyShare + interestShare;
        if (!member) return '';
        let csv = `SHG BANK - Member Report\n`;
        csv += `Name,${member.name}\nMobile,${member.mobile}\nJoining Date,${member.joiningDate}\n`;
        csv += `\n--- Summary ---\n`;
        csv += `Total Contribution,${totalContrib}\nPenalty Earnings,${penaltyShare}\nInterest Earnings,${interestShare}\nGrand Total,${grandTotal}\n`;

        // Monthly ROI Breakdown
        csv += `\n--- Monthly ROI (Earnings Breakdown) ---\n`;
        csv += `Month,Total Fund (Till Date),Interest Earned,Penalty Earned,Total Earnings,Cumulative Earnings\n`;

        // Get all months from joining date to now
        const joiningDate = new Date(member.joiningDate);
        const now = new Date();
        const allMonths: string[] = [];
        const cursor = new Date(joiningDate.getFullYear(), joiningDate.getMonth(), 1);
        while (cursor <= now) {
          allMonths.push(getMonthKey(cursor));
          cursor.setMonth(cursor.getMonth() + 1);
        }

        // Get member's contribution ratio for each month (based on cumulative contribution till that month)
        const allNonAdminMembers = get().members.filter(m => m.isActive && !m.isAdmin);
        let cumulativeEarnings = 0;

        allMonths.forEach(monthKey => {
          // Member's cumulative contribution till this month
          const memberContribTillMonth = get().contributions
            .filter(c => c.memberId === memberId && c.status === 'paid' && c.month <= monthKey)
            .reduce((sum, c) => sum + c.amount, 0);

          // Total contributions by all active members till this month
          const totalContribsTillMonth = allNonAdminMembers.reduce((sum, m) => {
            return sum + get().contributions
              .filter(c => c.memberId === m.id && c.status === 'paid' && c.month <= monthKey)
              .reduce((s, c) => s + c.amount, 0);
          }, 0);

          // Interest earned this month (from paid EMIs this month)
          const monthStart = monthKey + '-01';
          const [y, m] = monthKey.split('-').map(Number);
          const monthEnd = new Date(y, m, 0).toISOString().split('T')[0];
          const interestThisMonth = get().loans
            .filter(l => l.status !== 'recalled' && l.status !== 'rejected' && l.status !== 'pending' && l.openingDate >= member.joiningDate)
            .reduce((sum, l) => {
              return sum + l.emiHistory
                .filter(e => e.status === 'paid' && e.paidDate && e.paidDate >= monthStart && e.paidDate <= monthEnd)
                .reduce((s, e) => s + (e.interestComponent || 0), 0);
            }, 0);

          // Penalty earned this month
          const penaltyThisMonth = get().penalties
            .filter(p => p.date >= monthStart && p.date <= monthEnd && p.date >= member.joiningDate)
            .reduce((sum, p) => sum + p.amount, 0);

          // Member's share ratio
          const ratio = totalContribsTillMonth > 0 ? memberContribTillMonth / totalContribsTillMonth : 0;
          const memberInterestThisMonth = Math.round(interestThisMonth * ratio * 100) / 100;
          const memberPenaltyThisMonth = Math.round(penaltyThisMonth * ratio * 100) / 100;
          const totalEarningsThisMonth = Math.round((memberInterestThisMonth + memberPenaltyThisMonth) * 100) / 100;
          cumulativeEarnings = Math.round((cumulativeEarnings + totalEarningsThisMonth) * 100) / 100;

          if (totalEarningsThisMonth > 0 || memberContribTillMonth > 0) {
            csv += `${monthKey},${memberContribTillMonth},${memberInterestThisMonth},${memberPenaltyThisMonth},${totalEarningsThisMonth},${cumulativeEarnings}\n`;
          }
        });

        csv += `\n--- Contributions ---\nMonth,Amount,Status,Penalty,Paid Date\n`;
        contributions.forEach(c => {
          csv += `${c.month},${c.amount},${c.status},${c.penalty || 0},${c.paidDate || ''}\n`;
        });
        csv += `\n--- Loans ---\nLoan ID,Amount,Months,Interest,Total,Status,Opening Date\n`;
        loans.forEach(l => {
          csv += `${l.id},${l.amount},${l.months},${l.totalInterest},${l.totalPayable},${l.status},${l.openingDate}\n`;
        });
        return csv;
      },

      exportMonthlyCSV: (month) => {
        const contributions = get().contributions.filter(c => c.month === month);
        const [y, m] = month.split('-').map(Number);
        const monthStart = `${month}-01`;
        const monthEnd = new Date(y, m, 0).toISOString().split('T')[0];

        // Interest earned this month (from paid EMIs)
        const interestThisMonth = get().loans
          .filter(l => l.status === 'active' || l.status === 'completed')
          .reduce((sum, l) => {
            return sum + l.emiHistory
              .filter(e => e.status === 'paid' && e.paidDate && e.paidDate >= monthStart && e.paidDate <= monthEnd)
              .reduce((s, e) => s + (e.interestComponent || 0), 0);
          }, 0);

        // Penalty earned this month
        const penaltyThisMonth = get().penalties
          .filter(p => p.date >= monthStart && p.date <= monthEnd)
          .reduce((sum, p) => sum + p.amount, 0);

        // Manual interest this month
        const manualInterestThisMonth = get().manualInterests
          .filter(mi => mi.date >= monthStart && mi.date <= monthEnd)
          .reduce((sum, mi) => sum + mi.amount, 0);

        const totalROI = interestThisMonth + penaltyThisMonth + manualInterestThisMonth;

        let csv = `SHG BANK - Monthly Report - ${month}\n\n`;

        // ROI Summary
        csv += `--- Monthly ROI Summary ---\n`;
        csv += `Interest from Loans,${interestThisMonth}\n`;
        csv += `Penalty Collected,${penaltyThisMonth}\n`;
        csv += `Manual Interest,${manualInterestThisMonth}\n`;
        csv += `Total Earnings This Month,${totalROI}\n\n`;

        // Per-member share breakdown
        csv += `--- Member-wise ROI Share ---\n`;
        csv += `Name,Mobile,Contribution,Till Date Fund,ROI Share (Interest),ROI Share (Penalty),Total ROI Share,Cumulative Total\n`;

        const allNonAdminMembers = get().members.filter(mb => mb.isActive && !mb.isAdmin);
        allNonAdminMembers.forEach(mb => {
          const memberContrib = get().getMemberTotalContribution(mb.id);
          const contribTillMonth = get().contributions
            .filter(c => c.memberId === mb.id && c.status === 'paid' && c.month <= month)
            .reduce((sum, c) => sum + c.amount, 0);
          const totalContribsTillMonth = allNonAdminMembers.reduce((sum, mb2) => {
            return sum + get().contributions
              .filter(c => c.memberId === mb2.id && c.status === 'paid' && c.month <= month)
              .reduce((s, c) => s + c.amount, 0);
          }, 0);
          const ratio = totalContribsTillMonth > 0 ? contribTillMonth / totalContribsTillMonth : 0;
          const interestShare = Math.round(interestThisMonth * ratio * 100) / 100;
          const penaltyShare = Math.round(penaltyThisMonth * ratio * 100) / 100;
          const totalShare = Math.round((interestShare + penaltyShare + (mb.id ? 0 : 0)) * 100) / 100;
          const memberTotalEarnings = get().getMemberPenaltyShare(mb.id) + get().getMemberInterestShare(mb.id);

          csv += `${mb.name},${mb.mobile},${contribTillMonth},${memberContrib},${interestShare},${penaltyShare},${totalShare},${memberTotalEarnings}\n`;
        });

        // Contributions detail
        csv += `\n--- Contributions ---\n`;
        csv += `Name,Mobile,Amount,Status,Penalty,Paid Date\n`;
        contributions.forEach(c => {
          csv += `${c.memberName},${c.memberId},${c.amount},${c.status},${c.penalty},${c.paidDate || ''}\n`;
        });

        return csv;
      },

      // Computed getters
      getMember: (id) => get().members.find(m => m.id === id),
      getMemberByMobile: (mobile) => get().members.find(m => m.mobile === mobile),
      getMemberLoans: (memberId) => get().loans.filter(l => l.memberId === memberId),
      getMemberContributions: (memberId) => get().contributions.filter(c => c.memberId === memberId),
      
      getMemberTotalContribution: (memberId) => {
        return get().contributions
          .filter(c => c.memberId === memberId && c.status === 'paid')
          .reduce((sum, c) => sum + c.amount, 0);
      },

      getMemberPenaltyShare: (memberId) => {
        const member = get().getMember(memberId);
        if (!member) return 0;
        
        // Get all non-admin active members' contributions
        const nonAdminMembers = get().members.filter(m => m.isActive && !m.isAdmin);
        const totalContribs = nonAdminMembers.reduce((sum, m) => sum + get().getMemberTotalContribution(m.id), 0);
        
        // For admin: use average of non-admin members' contributions
        // For members: use their actual contribution
        let memberContrib: number;
        
        if (member.isAdmin) {
          // Admin gets average contribution like a regular member
          memberContrib = nonAdminMembers.length > 0 ? totalContribs / nonAdminMembers.length : 0;
        } else {
          memberContrib = get().getMemberTotalContribution(memberId);
        }
        
        // Use totalContribs (without admin) as denominator for ALL members including admin
        // This ensures admin gets equal share
        const effectiveTotal = totalContribs;
        
        if (effectiveTotal === 0) return 0;

        // Only penalties after member's joining date
        const joiningDate = new Date(member.joiningDate);
        const relevantPenalties = get().penalties.filter(p => new Date(p.date) >= joiningDate);
        const totalPenalty = relevantPenalties.reduce((sum, p) => sum + p.amount, 0);
        return Math.round((memberContrib / effectiveTotal) * totalPenalty * 100) / 100;
      },

      getMemberInterestShare: (memberId) => {
        const member = get().getMember(memberId);
        if (!member) return 0;
        
        // Get all non-admin active members' contributions
        const nonAdminMembers = get().members.filter(m => m.isActive && !m.isAdmin);
        const totalContribs = nonAdminMembers.reduce((sum, m) => sum + get().getMemberTotalContribution(m.id), 0);
        
        // For admin: use average of non-admin members' contributions
        // For members: use their actual contribution
        let memberContrib: number;
        
        if (member.isAdmin) {
          // Admin gets average contribution like a regular member
          memberContrib = nonAdminMembers.length > 0 ? totalContribs / nonAdminMembers.length : 0;
        } else {
          memberContrib = get().getMemberTotalContribution(memberId);
        }
        
        // Use totalContribs (without admin) as denominator for ALL members including admin
        // This ensures admin gets equal share
        const effectiveTotal = totalContribs;
        
        if (effectiveTotal === 0) return 0;

        // Only interest from loans given after member's joining date
        // Also filter: only include loans where includeInApp = true
        const joiningDate = new Date(member.joiningDate);
        const relevantLoans = get().loans.filter(l => {
          return l.status !== 'recalled' && l.status !== 'rejected' && l.status !== 'pending' 
            && new Date(l.openingDate) >= joiningDate 
            && l.includeInApp;
        });
        const totalInterest = relevantLoans.reduce((sum, l) => sum + l.totalInterest, 0);
        const calculatedShare = Math.round((memberContrib / effectiveTotal) * totalInterest * 100) / 100;

        // Add manual interest for this member
        const manualInterest = get().getMemberManualInterest(memberId);

        return Math.round((calculatedShare + manualInterest) * 100) / 100;
      },

      // Get pending interest for a member (interest to be distributed on 10th)
      getMemberPendingInterest: (memberId) => {
        const pending = get().pendingInterests.filter(p => p.memberId === memberId);
        return Math.round(pending.reduce((sum, p) => sum + p.amount, 0) * 100) / 100;
      },

      // Distribute all pending interests to members on the 10th
      distributePendingInterests: () => {
        const today = new Date();
        const todayStr = today.toISOString().split('T')[0];
        const currentMonth = today.toISOString().slice(0, 7); // YYYY-MM
        
        // Get all pending interests that are due (targetDate <= today)
        const duePending = get().pendingInterests.filter(p => p.targetDate <= todayStr);
        
        if (duePending.length === 0) return;
        
        // Group by member and convert to manual interest
        const memberInterestMap = new Map<string, number>();
        
        duePending.forEach(p => {
          const current = memberInterestMap.get(p.memberId) || 0;
          memberInterestMap.set(p.memberId, current + p.amount);
        });
        
        // Add as manual interest for each member
        memberInterestMap.forEach((amount, memberId) => {
          const member = get().getMember(memberId);
          if (member) {
            get().addManualInterest(
              memberId,
              Math.round(amount * 100) / 100,
              todayStr,
              `Auto: ${duePending.find(p => p.memberId === memberId)?.description || 'Loan interest'}`
            );
          }
        });
        
        // Remove distributed pending interests
        const distributedIds = new Set(duePending.map(p => p.id));
        set(s => ({
          pendingInterests: s.pendingInterests.filter(p => !distributedIds.has(p.id)),
          lastInterestDistribution: todayStr,
        }));
      },
      
      // Auto-distribute pending interest - called on admin login
      autoDistributePendingInterest: () => {
        const today = new Date();
        const todayStr = today.toISOString().split('T')[0];
        const currentMonth = today.toISOString().slice(0, 7);
        const lastDist = get().lastInterestDistribution;
        
        // Only distribute once per month, on or after the 10th
        const dayOfMonth = today.getDate();
        if (dayOfMonth < 10) return;
        
        // Check if we've already distributed this month
        if (lastDist && lastDist.slice(0, 7) === currentMonth) return;
        
        // Check if there are pending interests
        const pendingCount = get().pendingInterests.length;
        if (pendingCount > 0) {
          get().distributePendingInterests();
        }
      },

      getMemberTotalEarnings: (memberId) => {
        return get().getMemberPenaltyShare(memberId) + get().getMemberInterestShare(memberId);
      },

      getMemberGrandTotal: (memberId) => {
        return get().getMemberTotalContribution(memberId) + get().getMemberTotalEarnings(memberId);
      },

      getActiveLoans: () => get().loans.filter(l => l.status === 'active'),
      getPendingLoans: () => get().loans.filter(l => l.status === 'pending'),
      getTotalCollection: () => {
        return get().contributions.filter(c => c.status === 'paid').reduce((sum, c) => sum + c.amount, 0);
      },
      getTotalLoansGiven: () => {
        return get().loans
          .filter(l => l.status === 'active' || l.status === 'completed')
          .reduce((sum, l) => sum + l.amount, 0);
      },
      getRemainingBalance: () => {
        const collection = get().getTotalCollection();
        const loansGiven = get().getTotalLoansGiven();
        return collection - loansGiven;
      },
      getTotalPenaltyCollected: () => {
        return get().penalties.reduce((sum, p) => sum + p.amount, 0);
      },
      getTotalInterestCollected: () => {
        const loanInterest = get().loans
          .filter(l => {
            return (l.status === 'active' || l.status === 'completed') && l.includeInApp;
          })
          .reduce((sum, l) => sum + l.totalInterest, 0);
        const manualInterest = get().manualInterests.reduce((sum, m) => sum + m.amount, 0);
        return loanInterest + manualInterest;
      },
      getDefaulterNames: () => {
        const now = new Date();
        const currentMonth = getMonthKey(now);
        const contributions = get().contributions;
        return get().members
          .filter(m => m.isActive && !m.isAdmin)
          .filter(m => {
            // Check if any past contribution is unpaid
            const memberContribs = contributions.filter(c => c.memberId === m.id);
            return memberContribs.some(c => c.month < currentMonth && c.status !== 'paid');
          })
          .map(m => m.name);
      },
      seedHistoricalContributions: () => {
        const allMonths = ['2025-09', '2025-10', '2025-11', '2025-12', '2026-01', '2026-02', '2026-03'];
        const excludeNames = ['ADMIN'];
        const eligibleMembers = get().members.filter(m => !m.isAdmin && m.isActive && !excludeNames.includes(m.name));

        // Member-specific month overrides (joining date logic)
        const memberMonthOverrides: Record<string, string[]> = {
          'NANDINI': ['2026-02', '2026-03'],
          'RUPESH': ['2026-01', '2026-02', '2026-03'],
        };

        const newContributions: Contribution[] = [];
        const existingKeys = new Set(get().contributions.map(c => `${c.memberId}_${c.month}`));

        eligibleMembers.forEach(member => {
          const months = memberMonthOverrides[member.name] || allMonths;
          months.forEach(month => {
            const key = `${member.id}_${month}`;
            if (existingKeys.has(key)) return;
            const [y, m] = month.split('-').map(Number);
            const paidDate = new Date(y, m - 1, 10).toISOString();
            newContributions.push({
              id: generateId(),
              memberId: member.id,
              memberName: member.name,
              amount: get().settings.monthlyContribution,
              month,
              dueDate: new Date(y, m - 1, 11).toISOString(),
              paidDate,
              penalty: 0,
              status: 'paid',
              approvedByMember: true,
            });
          });
        });

        if (newContributions.length > 0) {
          set(s => ({ contributions: [...s.contributions, ...newContributions] }));
        }
      },

      canApplyLoan: (memberId) => {
        const member = get().getMember(memberId);
        if (!member) return false;
        const activeLoans = get().loans.filter(l => l.memberId === memberId && (l.status === 'active' || l.status === 'pending'));
        if (activeLoans.length > 0) {
          const eligible = activeLoans.every(l => {
            const paidEmis = l.emiHistory.filter(e => e.status === 'paid').length;
            return paidEmis >= Math.ceil(l.months / 2);
          });
          if (!eligible) return false;
        }
        return true;
      },

      getMemberMaxLoan: (memberId) => {
        const member = get().getMember(memberId);
        if (!member) return 0;
        const settings = get().settings;
        if (member.isActive || member.isAdmin) return settings.maxLoanAmount;
        // Inactive member: max loan = total contribution - active loan remaining
        const totalContrib = get().getMemberTotalContribution(memberId);
        const activeLoanRemaining = get().loans
          .filter(l => l.memberId === memberId && (l.status === 'active' || l.status === 'pending'))
          .reduce((sum, l) => sum + l.remainingAmount, 0);
        return Math.max(0, totalContrib - activeLoanRemaining);
      },

      toggleMemberActive: (memberId, inactiveDate) => {
        const member = get().getMember(memberId);
        if (!member || member.isAdmin) return;
        const nowDeactivating = member.isActive; // going from active → inactive
        set((state) => ({
          members: state.members.map(m =>
            m.id === memberId ? { ...m, isActive: !m.isActive, inactiveDate: nowDeactivating ? (inactiveDate || new Date().toISOString().split('T')[0]) : undefined } : m
          ),
        }));
      },

      calculateInterestForPeriod: (startDate, endDate) => {
        const start = new Date(startDate);
        const end = new Date(endDate);
        
        // Get all active/completed loans
        const relevantLoans = get().loans.filter(l => {
          return (l.status === 'active' || l.status === 'completed') && l.includeInApp;
        });
        
        let totalInterest = 0;
        
        for (const loan of relevantLoans) {
          // Calculate interest for EMIs that fall within the period
          for (const emi of loan.emiHistory) {
            const emiDueDate = new Date(emi.dueDate);
            
            // Check if this EMI falls within our period
            if (emiDueDate >= start && emiDueDate <= end) {
              // Only count interest from paid EMIs
              if (emi.status === 'paid') {
                totalInterest += emi.interestComponent;
              }
            }
          }
        }
        
        return Math.round(totalInterest * 100) / 100;
      },

      getPeriodInterestShare: (memberId, startDate, endDate) => {
        const member = get().getMember(memberId);
        if (!member) return 0;
        
        const totalInterest = get().calculateInterestForPeriod(startDate, endDate);
        if (totalInterest === 0) return 0;
        
        // Get all active non-admin members' contributions
        const nonAdminMembers = get().members.filter(m => m.isActive && !m.isAdmin);
        const totalContribs = nonAdminMembers.reduce((sum, m) => sum + get().getMemberTotalContribution(m.id), 0);
        
        if (totalContribs === 0) return 0;
        
        let memberContrib: number;
        let effectiveTotal: number;
        
        if (member.isAdmin) {
          // Admin gets equal share - average of all members
          const avgContrib = nonAdminMembers.length > 0 ? totalContribs / nonAdminMembers.length : 0;
          memberContrib = avgContrib;
          effectiveTotal = totalContribs + avgContrib;
        } else {
          memberContrib = get().getMemberTotalContribution(memberId);
          effectiveTotal = totalContribs;
        }
        
        const share = (memberContrib / effectiveTotal) * totalInterest;
        return Math.round(share * 100) / 100;
      },

      distributePeriodInterest: (startDate, endDate, description) => {
        const nonAdminMembers = get().members.filter(m => m.isActive && !m.isAdmin);
        const adminMember = get().members.find(m => m.isAdmin);
        
        for (const member of nonAdminMembers) {
          const share = get().getPeriodInterestShare(member.id, startDate, endDate);
          if (share > 0) {
            get().addManualInterest(member.id, share, endDate, description);
          }
        }
        
        // Also distribute to admin
        if (adminMember) {
          const adminShare = get().getPeriodInterestShare(adminMember.id, startDate, endDate);
          if (adminShare > 0) {
            get().addManualInterest(adminMember.id, adminShare, endDate, description);
          }
        }
      },
      
      // Reset all data to default - clears localStorage and reloads
      resetData: () => {
        localStorage.removeItem('shg-bank-storage');
        window.location.reload();
      },
    }),
    {
      name: 'shg-bank-storage',
      version: 2,
      migrate: (persistedState: unknown) => {
        return persistedState as Partial<AppState>;
      },
      merge: (persisted, current) => {
        const state = { ...current, ...(persisted as Partial<typeof current>) };
        // Remove unwanted members (karan, raju, poonam) and their fund data
        const membersToRemove = state.members
          .filter(m => MEMBERS_TO_REMOVE.includes(m.name.toLowerCase()))
          .map(m => m.id);
        
        if (membersToRemove.length > 0) {
          state.members = state.members.filter(m => !membersToRemove.includes(m.id));
          state.loans = state.loans.filter(l => !membersToRemove.includes(l.memberId));
          state.contributions = state.contributions.filter(c => !membersToRemove.includes(c.memberId));
          state.penalties = state.penalties.filter(p => !membersToRemove.includes(p.memberId));
          state.manualInterests = state.manualInterests.filter(mi => !membersToRemove.includes(mi.memberId));
        }
        return state;
      },
    }
  )
);
