export interface Member {
  id: string;
  name: string;
  mobile: string;
  password: string;
  joiningDate: string;
  profilePhoto?: string;
  isAdmin: boolean;
  isActive: boolean;
  inactiveDate?: string;
  language?: 'hi' | 'en' | 'ta';
  skipContribution?: boolean;
  jamaBalance: number; // Jama/collection balance
  autoDeductPenalty: boolean; // Auto-deduct late penalty from jama
}

export interface Loan {
  id: string;
  memberId: string;
  memberName: string;
  amount: number;
  interestRate: number;
  months: number;
  totalInterest: number;
  totalPayable: number;
  emiAmount: number;
  remainingAmount: number;
  openingDate: string;
  closingDate: string;
  nextEmiDate: string;
  status: 'pending' | 'approved' | 'active' | 'completed' | 'recalled' | 'rejected';
  includeInterest: boolean;
  isOldLoan: boolean;
  includeInApp: boolean; // Whether this loan is tracked in the app
  emiHistory: EMIRecord[];
}

export interface EMIRecord {
  id: string;
  loanId: string;
  memberId: string;
  emiNumber: number;
  amount: number;
  interestComponent: number;
  principalComponent: number;
  dueDate: string;
  paidDate?: string;
  penalty: number;
  status: 'paid' | 'pending' | 'overdue';
  approvedByMember: boolean;
}

export interface Contribution {
  id: string;
  memberId: string;
  memberName: string;
  amount: number;
  month: string;
  dueDate: string;
  paidDate?: string;
  penalty: number;
  status: 'paid' | 'pending' | 'overdue';
  approvedByMember: boolean;
}

export interface PenaltyRecord {
  id: string;
  memberId: string;
  type: 'contribution' | 'emi';
  referenceId: string;
  amount: number;
  date: string;
  daysLate: number;
}

export interface AppSettings {
  upiId: string;
  groupName: string;
  monthlyContribution: number;
  maxLoanAmount: number;
  interestRate: number;
  lateFeePerDay: number;
  dueDate: number;
}

export interface ManualInterestRecord {
  id: string;
  memberId: string;
  memberName: string;
  amount: number;
  date: string;
  description: string;
}

// Automatic pending interest from loans (will be distributed on 10th)
export interface PendingInterest {
  id: string;
  memberId: string;
  loanId: string;
  amount: number;
  createdDate: string;
  targetDate: string; // The 10th when this will be distributed
  description: string;
}

export interface Notification {
  id: string;
  targetMemberId?: string;
  message: string;
  date: string;
  type: 'broadcast' | 'loan_holder';
}

export interface MemberShare {
  memberId: string;
  penaltyEarnings: number;
  interestEarnings: number;
  totalEarnings: number;
  totalContribution: number;
  grandTotal: number;
}

export interface SavingsTransaction {
  id: string;
  memberId: string;
  memberName: string;
  type: 'deposit' | 'withdrawal';
  amount: number;
  date: string;
  description: string;
  interestEarned?: number;
}

export interface NotificationTemplate {
  id: string;
  name: string;
  message: string;
  type: 'reminder' | 'loan' | 'emi' | 'contribution' | 'festival' | 'custom';
}
